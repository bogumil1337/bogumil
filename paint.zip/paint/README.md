# SeventhLessonBeginningArtist
<p align="left">
<img src="https://user-images.githubusercontent.com/108148690/220466139-53b29625-39a7-4cef-9f89-d9c60b2e36a4.jpeg"/>
</p>
